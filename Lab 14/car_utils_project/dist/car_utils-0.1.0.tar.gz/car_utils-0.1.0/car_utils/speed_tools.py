def max_speed(speed_list):
    return max(speed_list)

def travel_time(distance_km, speed_kmh):
    return distance_km / speed_kmh

def speed_warning(speed):
    return speed > 120
