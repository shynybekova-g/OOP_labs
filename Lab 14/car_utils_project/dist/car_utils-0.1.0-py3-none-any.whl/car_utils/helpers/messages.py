def notify(text, level="INFO"):
    return f"[{level}] {text}"

def car_tag(model):
    return f"<Car: {model}>"
