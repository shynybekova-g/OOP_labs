from .engine_tools import engine_power, fuel_consumption, oil_change_needed
from .speed_tools import max_speed, travel_time, speed_warning
